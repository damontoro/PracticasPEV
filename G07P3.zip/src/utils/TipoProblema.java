package src.utils;

public enum TipoProblema {
		MAXIMIZACION, 
		MINIMIZACION
}
