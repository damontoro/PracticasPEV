package src.utils;

public enum TipoConst {
    CRECIENTE, COMPLETO, RAMPED_AND_HALF
}
